/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.user;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 *
 * @author UTSAV MORI
 */

public class Register extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Register</title>");            
            out.println("</head>");
            out.println("<body>");
            
            String name =request.getParameter("name");
            String ssidno =request.getParameter("ssid");
            String mobileno =request.getParameter("mobno");
            String address =request.getParameter("add");
            String city =request.getParameter("city");
            String state =request.getParameter("state");
            String member= request.getParameter("m");
             String things = request.getParameter("th");
            out.println(name);
            out.println(ssidno);
            out.println(address);
            out.println(city);
            out.println(state);
            out.println(member);
            out.println(mobileno);
            out.println(things);
            try{ 
            Class.forName ("com.mysql.jdbc.Driver");          
           Connection con= DriverManager.getConnection("jdbc:mysql//localhost:3307/entri_record","root","root");
            String q="insert into data _entri(name,ssidno,mobno,add,city,state,mem,things) values(?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt=con.prepareStatement(q);
            pstmt .setString(1,name);
            pstmt .setString(2,ssidno);
             pstmt .setString(3,mobileno);
             pstmt .setString(4,address);
             pstmt .setString(5,city);
             pstmt .setString(6,state);
             pstmt .setString(7,member);
              pstmt .setString(8,things);
            pstmt.executeUpdate();
            out.println("done....");
            }
            catch(Exception e){
                e.printStackTrace(); 
            }
            
            
            out.println("</body>");
            out.println("</html>");
        } finally { 
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
